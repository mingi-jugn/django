
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.binance, name='binance'),
    path('bybit', views.bybit, name='bybit'),
    path('introduce', views.introduce, name='introduce'),
    path('upbit', views.upbit, name='upbit'),
    path('bithumb', views.bithumb, name='bithumb'),


]