from django.shortcuts import render
import ccxt
import pandas as pd
import numpy as np
from fbprophet import Prophet
import simplejson
from datetime import datetime


# Create your views here.

def introduce(request):
    return render(request,"introduce.html")
def binance(request):

    binance = ccxt.binance()
    markets=  binance.load_markets()
    USDT_market= []
    for market in markets.keys():
        if market.endswith("USDT"):
            USDT_market.append(market)
    if request.method == "POST":

        coin = request.POST.get('coin')
        # if coin==None:
        #     coin = "BTC/USDT"
        threshold = request.POST.get('threshold')
        btc_ohlcv = binance.fetch_ohlcv(coin, timeframe='1h', since=None,)

        df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
        df.set_index('datetime', inplace=True)

        df = df.reset_index()
        df['ds'] = df['datetime']
        if threshold == "aver":
            df['y'] = (df['open'] + df['close']) / 2
        elif threshold == "open":
            df['y'] = df['open']
        elif threshold == "close":
            df['y'] = df['close']
        elif threshold == "high":
            df['y'] = df['high']
        else:
            df['y'] = df['low']
        data = df[['ds', 'y']]

        model = Prophet()
        model.fit(data)
        future = model.make_future_dataframe(periods=24, freq='H')
        forecast = model.predict(future)
        js_data = [0]*36
        js_data_lower = [0] * 36
        js_data_upper = [0] * 36
        for i in range(36):
            js_data_lower[i] = forecast['yhat_lower'][488 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data_upper[i] = forecast['yhat_upper'][488 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data[i] = forecast['yhat'][488+i]#999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
        context = {
            'js_date': forecast['ds'],
            'js_data': js_data,
            'js_data_upper': js_data_upper,
            'js_data_lower': js_data_lower,
            'USDT_market':USDT_market,
            'input_coin': coin

        }
    else:
        context = {
            'USDT_market': USDT_market,
        }
    return render(request, "binance.html",context)




def bybit(request):

    bybit= ccxt.bybit()
    markets=  bybit.load_markets()
    USDT_market= []
    for market in markets.keys():
        if market.endswith("USDT"):
            USDT_market.append(market)
    if request.method == "POST":

        coin = request.POST.get('coin')
        # if coin==None:
        #     coin = "BTC/USDT"
        threshold = request.POST.get('threshold')
        btc_ohlcv = bybit.fetch_ohlcv(coin, timeframe='1h', since=None,limit=200)

        df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
        df.set_index('datetime', inplace=True)

        df = df.reset_index()
        df['ds'] = df['datetime']
        if threshold == "aver":
            df['y'] = (df['open'] + df['close']) / 2
        elif threshold == "open":
            df['y'] = df['open']
        elif threshold == "close":
            df['y'] = df['close']
        elif threshold == "high":
            df['y'] = df['high']
        else:
            df['y'] = df['low']
        data = df[['ds', 'y']]

        model = Prophet()
        model.fit(data)
        future = model.make_future_dataframe(periods=24, freq='H')
        forecast = model.predict(future)
        js_data = [0]*36
        js_data_lower = [0] * 36
        js_data_upper = [0] * 36
        for i in range(36):
            js_data_lower[i] = forecast['yhat_lower'][188 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data_upper[i] = forecast['yhat_upper'][188 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data[i] = forecast['yhat'][188+i]#999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
        context = {
            'js_date': forecast['ds'],
            'js_data': js_data,
            'js_data_upper': js_data_upper,
            'js_data_lower': js_data_lower,
            'USDT_market':USDT_market,
            'input_coin': coin

        }
    else:
        context = {
            'USDT_market': USDT_market,
        }
    return render(request, "bybit.html",context)

def upbit(request):

    upbit= ccxt.upbit()
    markets=  upbit.load_markets()
    USDT_market= []
    for market in markets.keys():
        USDT_market.append(market)
    if request.method == "POST":

        coin = request.POST.get('coin')
        # if coin==None:
        #     coin = "BTC/USDT"
        threshold = request.POST.get('threshold')
        btc_ohlcv = upbit.fetch_ohlcv(coin, timeframe='1h', since=None,)

        df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
        df.set_index('datetime', inplace=True)

        df = df.reset_index()
        df['ds'] = df['datetime']
        if threshold == "aver":
            df['y'] = (df['open'] + df['close']) / 2
        elif threshold == "open":
            df['y'] = df['open']
        elif threshold == "close":
            df['y'] = df['close']
        elif threshold == "high":
            df['y'] = df['high']
        else:
            df['y'] = df['low']
        data = df[['ds', 'y']]

        model = Prophet()
        model.fit(data)
        future = model.make_future_dataframe(periods=24, freq='H')
        forecast = model.predict(future)
        js_data = [0]*36
        js_data_lower = [0] * 36
        js_data_upper = [0] * 36
        for i in range(36):
            js_data_lower[i] = forecast['yhat_lower'][188 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data_upper[i] = forecast['yhat_upper'][188 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data[i] = forecast['yhat'][188+i]#999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
        context = {
            'js_date': forecast['ds'],
            'js_data': js_data,
            'js_data_upper': js_data_upper,
            'js_data_lower': js_data_lower,
            'USDT_market':USDT_market,
            'input_coin': coin

        }
    else:
        context = {
            'USDT_market': USDT_market,
        }
    return render(request, "upbit.html",context)
def bithumb(request):

    bithumb= ccxt.bithumb()
    markets= bithumb.load_markets()
    USDT_market= []
    for market in markets.keys():
        USDT_market.append(market)
    if request.method == "POST":

        coin = request.POST.get('coin')
        # if coin==None:
        #     coin = "BTC/USDT"
        threshold = request.POST.get('threshold')
        btc_ohlcv = bithumb.fetch_ohlcv(coin, timeframe='1h', since=None,limit=500)

        df = pd.DataFrame(btc_ohlcv, columns=['datetime', 'open', 'high', 'low', 'close', 'volume'])
        df['datetime'] = pd.to_datetime(df['datetime'], unit='ms')
        df.set_index('datetime', inplace=True)

        df = df.reset_index()
        df['ds'] = df['datetime']
        if threshold == "aver":
            df['y'] = (df['open'] + df['close']) / 2
        elif threshold == "open":
            df['y'] = df['open']
        elif threshold == "close":
            df['y'] = df['close']
        elif threshold == "high":
            df['y'] = df['high']
        else:
            df['y'] = df['low']
        data = df[['ds', 'y']]

        model = Prophet()
        model.fit(data)
        future = model.make_future_dataframe(periods=24, freq='H')
        forecast = model.predict(future)
        js_data = [0]*36
        js_data_lower = [0] * 36
        js_data_upper = [0] * 36
        for i in range(36):
            js_data_lower[i] = forecast['yhat_lower'][488 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data_upper[i] = forecast['yhat_upper'][488 + i]  # 999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
            js_data[i] = forecast['yhat'][488+i]#999까지는 진짜 1000~1023까지는 예측된 데이터 총 24hour
        context = {
            'js_date': forecast['ds'],
            'js_data': js_data,
            'js_data_upper': js_data_upper,
            'js_data_lower': js_data_lower,
            'USDT_market':USDT_market,
            'input_coin': coin

        }
    else:
        context = {
            'USDT_market': USDT_market,
        }
    return render(request, "bithumb.html",context)